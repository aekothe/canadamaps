#Mapping Metropolitan Areas
#Angela Kothe
library(devtools)
library(mapcan)
library(tidyverse)
library(socviz)
library(scales)
library(cowplot)

census_choropleth_data <- mapcan(boundaries = census,
                                 type = standard)

census_pop2016 <- mapcan::census_pop2016

cd2016 <- census_divisions_2016

cd2016$census_code <- cd2016$census_division_code

census <- left_join(cd2016, census_pop2016, by = "census_code")

#Greater Toronto Area
tometro <- read_csv(file="/Users/annkothe/desktop/r/mapcan/tocodes.csv")
gta_data <- left_join(tometro, census, by = "census_code")

ggplot(gta_data, aes(long, lat, group = group, fill = born_outside_canada_share)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "Share of population born \noutside of Canada") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population cartogram of foerign born population by census division")

ggplot(gta_data, aes(long, lat, group = group, fill = population_density_2016)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "Population Density") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population Density")


#Golden Horseshoe
goldenhorseshoe <- read_csv(file="/Users/annkothe/desktop/r/mapcan/goldenhorseshoecodes.csv")
horse_data <- left_join(goldenhorseshoe, census, by = "census_code")

ggplot(horse_data, aes(long, lat, group = group, fill = born_outside_canada_share)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "Share of population born \noutside of Canada") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population cartogram of foreign born population by census division")

ggplot(horse_data, aes(long, lat, group = group, fill = population_density_2016)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "Population Density") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population Density")

#Greater Vancouver Area
vanmetro <- read_csv(file="/Users/annkothe/desktop/r/mapcan/vanmetrocodes.csv")
vanmetro <- left_join(vanmetro, census, by = "census_code")

ggplot(vanmetro, aes(long, lat, group = group, fill = born_outside_canada_share)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "Share of population born \noutside of Canada") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population cartogram of foerign born population by census division")

ggplot(vanmetro, aes(long, lat, group = group, fill = population_density_2016)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "Population Density") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population Density")

#Greater Montreal Area
montrealmetro <- read_csv(file="/Users/annkothe/desktop/r/mapcan/montrealmetro.csv")
montrealmetro <- left_join(montrealmetro, census, by = "census_code")

ggplot(montrealmetro, aes(long, lat, group = group, fill = born_outside_canada_share)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "Share of population born \noutside of Canada") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population cartogram of foerign born population by census division")

ggplot(montrealmetro, aes(long, lat, group = group, fill = population_density_2016)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "Population Density") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population Density")


#Quebec City - Windsor Corridor