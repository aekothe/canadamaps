#Mapping Urban Ridings
#Angela Kothe

#Toronto
on_ridings <- mapcan(boundaries = ridings,
                     type = standard,
                     province = ON)

torontoridings <- read_csv(file="/Users/annkothe/desktop/r/mapcan/torontoridings.csv")

to_ridings <- inner_join(torontoridings, on_ridings, by = "riding_name_english")

ggplot(to_ridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Toronto Ridings")

on_results <- mapcan::federal_election_results %>%
  filter(election_year == 2015 & pr_alpha == "ON")

to_riding_maps <- inner_join(to_ridings, on_results, by = "riding_code")

to_riding_map <- to_riding_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Toronto 2015 Federal Electoral Results")
to_riding_map +
  scale_fill_manual(name = "Winning party",
                    values = c("red", "Orange")) 

#Greater Toronto Area
gtaridings <- read_csv(file="/Users/annkothe/desktop/r/mapcan/gtaridings.csv")

gtamaps <- inner_join(gtaridings, on_ridings, by = "riding_name_english")

ggplot(gtamaps, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Toronto Ridings")


gta_riding_maps <- inner_join(gtamaps, on_results, by = "riding_code")

gta_riding_map <- gta_riding_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Greater Toronto 2015 Federal Electoral Results")
gta_riding_map +
  scale_fill_manual(name = "Winning party",
                    values = c("Blue", "Red")) 
#Hamilton-Niagara
hamiltonridings <- read_csv(file="/Users/annkothe/desktop/r/mapcan/hamiltonniagara.csv")

hammaps <- inner_join(hamiltonridings, on_ridings, by = "riding_name_english")

ggplot(hammaps, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Hamilton-Niagara Ridings")


ham_riding_maps <- inner_join(hammaps, on_results, by = "riding_code")

ham_riding_map <- ham_riding_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Hamilton-Niagara 2015 Federal Electoral Results")
ham_riding_map +
  scale_fill_manual(name = "Winning party",
                    values = c("Blue", "Red", "orange")) 

#Vancouver
bc_ridings <- mapcan(boundaries = ridings,
                     type = standard,
                     province = BC)

vancouverridings <- read_csv(file="/Users/annkothe/desktop/r/mapcan/vancouver.csv")

van_ridings <- inner_join(vancouverridings, bc_ridings, by = "riding_name_english")

ggplot(van_ridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Vancouver Ridings")

bc_results <- mapcan::federal_election_results %>%
  filter(election_year == 2015 & pr_alpha == "BC")

van_riding_maps <- inner_join(van_ridings, bc_results, by = "riding_code")

van_riding_map <- van_riding_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Vancouver 2015 Federal Electoral Results")
van_riding_map +
  scale_fill_manual(name = "Winning party",
                    values = c("red", "Orange")) 

#Greater Vancouver
gvancouverridings <- read_csv(file="/Users/annkothe/desktop/r/mapcan/greatervancouver.csv")

greatervan_ridings <- inner_join(gvancouverridings, bc_ridings, by = "riding_name_english")

ggplot(greatervan_ridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Vancouver Ridings")

gvan_riding_maps <- inner_join(greatervan_ridings, bc_results, by = "riding_code")

gvan_riding_map <- gvan_riding_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Vancouver 2015 Federal Electoral Results")
gvan_riding_map +
  scale_fill_manual(name = "Winning party",
                    values = c("red", "blue", "Orange")) 

#Quebec City
qc_ridings <- mapcan(boundaries = ridings,
                     type = standard,
                     province = QC)

quebecridings <- read_csv(file="/Users/annkothe/desktop/r/mapcan/quebeccity.csv")

qcityridings <- inner_join(quebecridings, qc_ridings, by = "riding_name_english")

ggplot(qcityridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Quebec City Ridings")

qc_results <- mapcan::federal_election_results %>%
  filter(election_year == 2015 & pr_alpha == "QC")

qcity_riding_maps <- inner_join(qcityridings, qc_results, by = "riding_code")

qcity_riding_map <- qcity_riding_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Quebec City 2015 Federal Electoral Results")
qcity_riding_map +
  scale_fill_manual(name = "Winning party",
                    values = c("Blue", "red")) 

#Greater Montreal
gmontrealridings <- read_csv(file="/Users/annkothe/desktop/r/mapcan/greatermontreal.csv")

greatermontreal_ridings <- inner_join(gmontrealridings, qc_ridings, by = "riding_name_english")

ggplot(greatermontreal_ridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Greater Montreal Ridings")

gmon_riding_maps <- inner_join(greatermontreal_ridings, qc_results, by = "riding_code")

gmon_riding_map <- gmon_riding_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Greater Montreal 2015 Federal Electoral Results")
gmon_riding_map +
  scale_fill_manual(name = "Winning party",
                    values = c("skyblue", "red", "Orange"))

#Winnipeg
mb_ridings <- mapcan(boundaries = ridings,
                     type = standard,
                     province = MB)

winnipegridings <- read_csv(file="/Users/annkothe/desktop/r/mapcan/winnipeg.csv")

winnipegridings <- inner_join(winnipegridings, mb_ridings, by = "riding_name_english")

ggplot(winnipegridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Winnipeg City Ridings")

mb_results <- mapcan::federal_election_results %>%
  filter(election_year == 2015 & pr_alpha == "MB")

winnipeg_riding_maps <- inner_join(winnipegridings, mb_results, by = "riding_code")

winnipeg_riding_map <- winnipeg_riding_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Winnipeg 2015 Federal Electoral Results")
winnipeg_riding_map +
  scale_fill_manual(name = "Winning party",
                    values = c("red", "orange"))

#Regina
sk_ridings <- mapcan(boundaries = ridings,
                     type = standard,
                     province = SK)

reginaridings <- read_csv(file="/Users/annkothe/desktop/r/mapcan/regina.csv")

reginaridings <- inner_join(reginaridings, sk_ridings, by = "riding_name_english")

ggplot(reginaridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Regina City Ridings")

sk_results <- mapcan::federal_election_results %>%
  filter(election_year == 2015 & pr_alpha == "SK")

regina_riding_maps <- inner_join(reginaridings, sk_results, by = "riding_code")

regina_riding_map <- regina_riding_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Regina 2015 Federal Electoral Results")
regina_riding_map +
  scale_fill_manual(name = "Winning party",
                    values = c("blue", "red", "orange"))

#Saskatoon
sk_ridings <- mapcan(boundaries = ridings,
                     type = standard,
                     province = SK)

saskatoonridings <- read_csv(file="/Users/annkothe/desktop/r/mapcan/saskatoon.csv")

saskatoonridings <- inner_join(saskatoonridings, sk_ridings, by = "riding_name_english")

ggplot(saskatoonridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Saskatoon City Ridings")

sk_results <- mapcan::federal_election_results %>%
  filter(election_year == 2015 & pr_alpha == "SK")

saskatoon_riding_maps <- inner_join(saskatoonridings, sk_results, by = "riding_code")

saskatoon_riding_map <- saskatoon_riding_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Saskatoon 2015 Federal Electoral Results")
saskatoon_riding_map +
  scale_fill_manual(name = "Winning party",
                    values = c("blue", "orange"))

#Edmonton
ab_ridings <- mapcan(boundaries = ridings,
                     type = standard,
                     province = AB)

edmontonridings <- read_csv(file="/Users/annkothe/desktop/r/mapcan/edmonton.csv")

edmontonridings <- inner_join(edmontonridings, ab_ridings, by = "riding_name_english")

ggplot(edmontonridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Edmonton City Ridings")

ab_results <- mapcan::federal_election_results %>%
  filter(election_year == 2015 & pr_alpha == "AB")

edmonton_riding_maps <- inner_join(edmontonridings, ab_results, by = "riding_code")

edmonton_riding_map <- edmonton_riding_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Edmonton 2015 Federal Electoral Results")
edmonton_riding_map +
  scale_fill_manual(name = "Winning party",
                    values = c("blue", "red", "orange"))

#Calgary
calgaryridings <- read_csv(file="/Users/annkothe/desktop/r/mapcan/calgary.csv")

calgaryridings <- inner_join(calgaryridings, ab_ridings, by = "riding_name_english")

ggplot(calgaryridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Calgary City Ridings")

calgary_riding_maps <- inner_join(calgaryridings, ab_results, by = "riding_code")

calgary_riding_map <- calgary_riding_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Calgary 2015 Federal Electoral Results")
calgary_riding_map +
  scale_fill_manual(name = "Winning party",
                    values = c("blue", "red", "orange"))
