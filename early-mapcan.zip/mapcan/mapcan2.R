library(devtools)
#install_github("mccormackandrew/mapcan", build_vignettes = TRUE)
library(mapcan)
library(tidyverse)
library(socviz)
library(scales)
library(cowplot)

fed2015 <- mapcan::federal_election_results %>%
  filter(election_year == 2015)

#Draw Canada
mapcan(boundaries = province,
       type = standard) %>%
  head()

pr_map <- mapcan(boundaries = province,
                 type = standard) %>%
  ggplot(aes(x = long, y = lat, group = group))
pr_map

pr_map <- pr_map +
  geom_polygon() +
  coord_fixed()
pr_map

pr_map +
  theme_mapcan() +
  ## Add a title
  ggtitle("Map of Canada with Provincial/Territorial Boundaries")
#bins

riding_binplot(riding_data = fed2015,
               value_col = party, 
               arrange = TRUE,
               continuous = FALSE) +
  scale_fill_manual(name = "Party",
                    values = c("mediumturquoise", "blue", "springgreen3", "red", "orange")) + theme_mapcan() +
  ggtitle("Tile grid map of 2015 federal election results")

?riding_binplot


riding_binplot(riding_data = ridingdirty,
               # Use the party (winning party) varibale from fed2015
               value_col = party, 
               # Arrange by value_col within provinces
               arrange = TRUE,
               # party is a categorical variable
               continuous = FALSE,
               shape = "hexagon") +
  # Change the colours to match the parties' colours
  scale_fill_manual(name = "Party",
                    values = c("mediumturquoise", "blue", "springgreen3", "red", "orange")) +
  # mapcan ggplot theme removes axis labels, background grid, and other unnecessary elements when plotting maps
  theme_mapcan() +
  ggtitle("Hex tile map of 2015 federal election results")

riding_binplot(riding_data = ridingdirty,
               # Use the party (winning party) varibale from fed2015
               value_col = party, 
               # Arrange by value_col within provinces
               arrange = TRUE,
               # party is a categorical variable
               continuous = FALSE,
               shape = "hexagon") +
  # Change the colours to match the parties' colours
  scale_fill_manual(name = "Party",
                    values = c("mediumturquoise", "blue", "springgreen3", "red", "orange")) +
  # mapcan ggplot theme removes axis labels, background grid, and other unnecessary elements when plotting maps
  theme_mapcan() +
  ggtitle("Hex tile map of 2015 federal election results")


# Load data that will be plotted with riding_binplot 
riding_binplot(quebec_provincial_results,
               value_col = party,
               riding_col = riding_code, 
               continuous = FALSE, 
               provincial = TRUE,
               province = QC,
               shape = "hexagon") +
  theme_mapcan() +
  scale_fill_manual(name = "Winning party", 
                    values = c("deepskyblue1", "red","royalblue4",  "orange")) +
  ggtitle("Hex tile map of 2018 Quebec election results")


# Get census born outside of Canada data to use with geographic data
census_immigrant_share <- mapcan::census_pop2016 %>%
  select(census_division_code, born_outside_canada_share)

# Get population cartogram geograpic data - contains CD long and lat
census_choropleth_data <- mapcan(boundaries = census,
                                 type = standard)

# Merge together 
census_choropleth_data <- left_join(census_choropleth_data, census_immigrant_share)

ggplot(census_choropleth_data, aes(long, lat, group = group, fill = born_outside_canada_share)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "Share of population born \noutside of Canada") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population cartogram of foerign born population by census division")



#La La La La
census_choropleth_data <- left_join(census_choropleth_data, fed2015)

ggplot(census_choropleth_data, aes(long, lat, group = group, fill = factor(party))) +
  geom_polygon() +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population cartogram of foerign born population by census division")

party_colors <- c("#2E74C0","#CB454A") 
p <- ggplot(data = census_choropleth_data,
            mapping = aes(x = long, y = lat, fill = factor(party), 
                          group = group))
p1 <- p + geom_polygon(color = "gray90", size = 0.05) + coord_equal()
p2 <- p1 + scale_fill_manual(values = party_colors)
p2 + labs(fill = "US Presidential Election by County 2000") + 
  guides(fill = guide_legend(nrow = 2)) +  theme_map() + theme(legend.position = "top")


#ridings
mapcan(boundaries = province,
       type = standard) %>%
  head()

pr_map <- mapcan(boundaries = province,
                 type = standard) %>%
  ggplot(aes(x = long, y = lat, group = group))
pr_map

pr_map <- pr_map +
  geom_polygon() +
  coord_fixed()
pr_map

pr_map +
  theme_mapcan() +
  ## Add a title
  ggtitle("Map of Canada with Provincial/Territorial Boundaries")

pop_2017 <- mapcan::province_pop_annual %>%
  filter(year == 2017)

head(pop_2017)

pr_geographic <- mapcan(boundaries = province,
                        type = standard)
pr_geographic <- inner_join(pr_geographic, 
                            pop_2017, 
                            by = c("pr_english" = "province"))

pr_geographic %>%
  ggplot(aes(x = long, y = lat, group = group, fill = population)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  scale_fill_viridis_c(name = "Population") +
  ggtitle("Canadian Population by Province")

#BC, colors work
bc_ridings <- mapcan(boundaries = ridings,
                     type = standard,
                     province = BC)
head(bc_ridings)

ggplot(bc_ridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("British Columbia \nFederal Electoral Ridings")

bc_results <- mapcan::federal_election_results %>%
  # Restrict data to include just 2015 election results from BC
  filter(election_year == 2015 & pr_alpha == "BC")
head(bc_results)
bc_ridings <- inner_join(bc_results, bc_ridings, by = "riding_code")
bc_riding_map <- bc_ridings %>%
  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("British Columbia \n2015 Federal Electoral Results")
  
  bc_riding_map +
  scale_fill_manual(name = "Winning party",
                    values = c("blue", "springgreen3", "red", "Orange")) 

#nation riding map
ridingwiththehomies <- mapcan(boundaries = ridings,
                                     type = standard)
ridingwiththehomies <- left_join(ridingwiththehomies, fed2015, by = "riding_code")
ggplot(ridingwiththehomies, aes(x = long, y = lat, group = group, fill = "Party")) +
  geom_polygon() +
  coord_fixed() +
  scale_fill_manual(name = "Party",
                    values = c("mediumturquoise", "blue", "springgreen3", "red", "orange")) +
  theme_mapcan() +
  ggtitle("Federal Electoral Ridings")


election15 <- subset(fed2015, select=c(riding_code, party, population, voter_turnout, riding_name_english,
                                       riding_name_french, pr_english, pr_french))
ridingwiththehomies2 <- subset(ridingwiththehomies, select=c(long, lat, order, hole, piece,
                                                            group, riding_code))
ridingdirty <- left_join(ridingwiththehomies2, election15,by = "riding_code")

p <- ggplot(data = ridingdirty,
            mapping = aes(x = long, y = lat, fill = "party", 
                          group = group))
p1 <- p + geom_polygon(color = "gray90", size = 0.05) + coord_equal()
p2 <- p1 +  scale_color_manual(values = c("Conservative" = "blue", "Liberal" = "red",
                                          "Bloc" = "deepskyblue1", "NDP" = "orange",
                                          "Green" = "springgreen3"))
p2 + labs(fill = "US Presidential Election by County 2000") + 
  guides(fill = guide_legend(nrow = 2)) +  theme_map() + theme(legend.position = "top")

#
party_colors <- c("blue", "springgreen3", "red", "Orange", "deepskyblue1")
p <- ggplot(data = ridingdirty,
            mapping = aes(x = long, y = lat, fill = "party", 
                          group = group))
p1 <- p + geom_polygon(color = "gray90", size = 0.05) + coord_equal()
p2 <- p1 + scale_fill_manual(values = party_colors)
p2 + labs(fill = "Election by Riding 2015") + 
  guides(fill = guide_legend(nrow = 2)) +  theme_map() + theme(legend.position = "top")

ggplot(ridingdirty, aes(long, lat, group = group, fill = factor(party))) +
  geom_polygon() +
  scale_fill_viridis_c(name = "Share of population born \noutside of Canada") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population cartogram of foerign born population by census division")

#turnout
ggplot(ridingdirty, aes(long, lat, group = group, fill = voter_turnout)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Turnout by Riding, 2015")

#riding population 2015
ggplot(ridingdirty, aes(long, lat, group = group, fill = population)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population by Riding, 2015")

#riding
ridingdirty$winner <- ridingdirty$party
ridingdirty <- subset(ridingdirty, select=c(long, lat, riding_code))

saskyroughridings <- left_join(ridingdirty, election15, by = "riding_code")
ggplot(saskyroughridings, aes(long, lat, fill = factor(party))) +
  geom_polygon() +
  scale_fill_viridis_c(name = "") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population by Riding, 2015")


###
ridingwiththehomies <- mapcan(boundaries = ridings,
                              type = standard)
ridingwiththehomies <- left_join(ridingwiththehomies, fed2015, by = "riding_code")
p1 <- ggplot(ridingwiththehomies, aes(x = long, y = lat, group = group, fill = "Party")) +
   geom_polygon() +
   coord_fixed() +
   theme_mapcan() +
   ggtitle("Federal Electoral Ridings")

p1 +
  scale_fill_manual(name = "Winning party",
                    values = c("blue", "springgreen3", "red", "Orange")) 

#Ontario
on_ridings <- mapcan(boundaries = ridings,
                     type = standard,
                     province = ON)
head(on_ridings)

ggplot(on_ridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Ontario \nFederal Electoral Ridings")

on_results <- mapcan::federal_election_results %>%
  filter(election_year == 2015 & pr_alpha == "BC")

on_ridings <- inner_join(on_results, on_ridings, by = "riding_code")
on_riding_map <- on_ridings %>%
p2 <-  ggplot(aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Ontario \n2015 Federal Electoral Results")

p2 +
  scale_fill_manual(name = "Winning party",
                    values = c("blue", "springgreen3", "red", "Orange")) 