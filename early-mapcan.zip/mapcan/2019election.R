#2019 Election
#Angela Kothe

library(devtools)
library(mapcan)
library(tidyverse)
library(socviz)
library(scales)
library(cowplot)

#national
ridings <- mapcan(boundaries = ridings,
                        type = standard)

ggplot(ridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Federal Electoral Ridings")

riding_results <- read_csv(file="/Users/annkothe/desktop/r/mapcan/2019simplified.csv")
riding_results$riding_code <- riding_results$ridingNumber
map2019 <- inner_join(ridings, riding_results, by = "riding_code")

mapnat <- map2019%>%
  ggplot(aes(x = long, y = lat, group = group, fill = electedParty)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("2019 Federal Election Results")

mapnat +
  scale_fill_manual(name = "Elected party",
                    values = c("skyblue", "blue", "green", "gray", "red", "orange")) 

#Greater Toronto Area
on_ridings <- mapcan(boundaries = ridings,
                     type = standard,
                     province = ON)

ggplot(on_ridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Ontario Electoral Ridings")

torontoridings <- read_csv(file="/Users/annkothe/desktop/r/mapcan/gtaridings.csv")
gta <- left_join(torontoridings, map2019, by = "riding_name_english")

gta2019 <- gta%>%
  ggplot(aes(x = long, y = lat, group = group, fill = electedParty)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("2019 Federal Election Results")

gta2019 +
  scale_fill_manual(name = "Elected party",
                    values = c("blue", "red", "orange")) 

#Greater Montreal Area
qc_ridings <- mapcan(boundaries = ridings,
                     type = standard,
                     province = QC)

ggplot(qc_ridings, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Quebec Electoral Ridings")

montreal <- read_csv(file="/Users/annkothe/desktop/r/mapcan/greatermontreal.csv")

gma <- left_join(montreal, map2019, by = "riding_name_english")

gma2019 <- gma%>%
  ggplot(aes(x = long, y = lat, group = group, fill = electedParty)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("2019 Federal Election Results")

gma2019 +
  scale_fill_manual(name = "Elected party",
                    values = c("skyblue", "red", "orange")) 

#turnout
ggplot(map2019, aes(long, lat, group = group, fill = voterTurnout)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Turnout by Riding, 2019")

ggplot(gta, aes(long, lat, group = group, fill = voterTurnout)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Turnout by Torontonian Riding, 2019")

#Vote Percentage
ggplot(map2019, aes(long, lat, group = group, fill = pctVote)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Percentage of the Vote Received by \nWinning Party, 2019")

ggplot(gta19, aes(long, lat, group = group, fill = pctVote)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Percentage of the Vote Received by \nWinning Party in Toronto, 2019")

ggplot(gma, aes(long, lat, group = group, fill = pctVote)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Percentage of the Vote Received by \nWinning Party in Montreal, 2019")

#Percentage Majority
ggplot(map2019, aes(long, lat, group = group, fill = pctMajority)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Percentage Majority, 2019")
