#Riding Info. 2015-2019
#Angela Kothe

library(devtools)
library(mapcan)
library(tidyverse)
library(socviz)
library(scales)
library(cowplot)
library(gganimate)
library(gifski)
library(av)

census <- mapcan(boundaries = census,
                       type = standard)
ridings <- mapcan(boundaries = ridings,
                        type = standard)
election <- read_csv(file="/Users/annkothe/desktop/r/mapcan/data/2019simplified.csv")
population <- read_csv(file="/Users/annkothe/desktop/r/mapcan/data/popestimates2016.csv")
election$riding_code <- election$ridingNumber
ridingdata <- left_join(ridings, election, by = "riding_code")
election2015 <- mapcan::federal_election_results %>%
                filter(election_year == 2015)
election15 <- left_join(ridings, election2015, by = "riding_code")

#riding population, 2015
ggplot(election15, aes(long, lat, group = group, fill = population)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population by Riding, 2015") +
  theme(legend.position = "right")

#riding population, 2019
ggplot(ridingdata, aes(long, lat, group = group, fill = ridingPopulation)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Population by Riding, 2019") +
  theme(legend.position = "right")

#number of polling stations
ggplot(ridingdata, aes(long, lat, group = group, fill = pollingStations)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Number of Polling Stations, 2019") +
  theme(legend.position = "right")

#polling stations by population
ridingdata$pollspercapita <- ridingdata$ridingPopulation/ridingdata$pollingStations

ggplot(ridingdata, aes(long, lat, group = group, fill = pollspercapita)) +
  geom_polygon() +
  scale_fill_viridis_c(name = "") +
  theme_mapcan() +
  coord_fixed() +
  ggtitle("Persons per Polling Stations by Riding, 2019") +
  theme(legend.position = "right")

#gta persons per polling stations