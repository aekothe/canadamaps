#Cholorpeths Canadian Provinces
#Angela Kothe

library(devtools)
library(mapcan)
library(tidyverse)
library(socviz)
library(scales)
library(cowplot)

fed2015 <- mapcan::federal_election_results %>%
  filter(election_year == 2015)

census_cartogram_data <- mapcan(boundaries = census,
                                type = cartogram)

census_pop2016 <- mapcan::census_pop2016

cd2016 <- census_divisions_2016

cd2016$census_code <- cd2016$census_division_code

census <- left_join(cd2016, census_pop2016, by = "census_code")



#Born Outside Canada Share
ggplot(census, aes(long, lat, group = group, fill = born_outside_canada_share)) +
       geom_polygon() +
       scale_fill_viridis_c(name = "") +
       theme_mapcan() +
       coord_fixed() +
       ggtitle("Foreign Population by Census Division")

#Born Outside Canada Share, Ontario
on_cd <- mapcan(boundaries = census,
                      type = standard,
                  province = ON)

ggplot(on_map, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Ontario Census Divison")

on_pop <- mapcan::census_pop2016 %>%
  filter(pr_alpha == "ON")

on_pop$census_division_code <- on_pop$census_code

on_maps <- inner_join(on_cd, on_pop, by = "census_division_code")

on_cd_map <- on_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = born_outside_canada_share)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Born Outside Canada Share, 2015")
on_cd_map +  scale_fill_gradient(
  name = "Population",
  low = "#132B43",
  high = "#56B1F7",
  space = "Lab",
  na.value = "grey50",
  guide = "colourbar",
  aesthetics = "fill")

#Born Outside Canada Share, British Columbia
bc_cd <- mapcan(boundaries = census,
                type = standard,
                province = BC)

ggplot(bc_cd, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("British Columbia Census Divison")

bc_pop <- mapcan::census_pop2016 %>%
  filter(pr_alpha == "BC")

bc_pop$census_division_code <- bc_pop$census_code

bc_maps <- inner_join(bc_cd, bc_pop, by = "census_division_code")

bc_cd_map <- bc_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = born_outside_canada_share)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Born Outside Canada Share, 2015")
bc_cd_map +  scale_fill_gradient(
  name = "Population",
  low = "#132B43",
  high = "#56B1F7",
  space = "Lab",
  na.value = "grey50",
  guide = "colourbar",
  aesthetics = "fill")

#Born Outside Canada Share, Quebec
qc_cd <- mapcan(boundaries = census,
                type = standard,
                province = QC)

ggplot(qc_cd, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Quebec Census Divison")

qc_pop <- mapcan::census_pop2016 %>%
  filter(pr_alpha == "QC")

qc_pop$census_division_code <- qc_pop$census_code

qc_maps <- inner_join(qc_cd, qc_pop, by = "census_division_code")

qc_cd_map <- qc_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = born_outside_canada_share)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Born Outside Canada Share, 2015")
qc_cd_map +  scale_fill_gradient(
  name = "Population",
  low = "#132B43",
  high = "#56B1F7",
  space = "Lab",
  na.value = "grey50",
  guide = "colourbar",
  aesthetics = "fill")

#Population Density
on_cd <- mapcan(boundaries = census,
                type = standard,
                province = ON)

ggplot(on_map, aes(x = long, y = lat, group = group)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Ontario Census Divison")

on_pop <- mapcan::census_pop2016 %>%
  filter(pr_alpha == "ON")

on_pop$census_division_code <- on_pop$census_code

on_maps <- inner_join(on_cd, on_pop, by = "census_division_code")

on_cd_map <- on_maps %>%
  ggplot(aes(x = long, y = lat, group = group, fill = population_density_2016)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("Population Density, 2016") +
  show.legend = FALSE
on_cd_map +  scale_fill_gradient(
  name = "Population",
  low = "#132B43",
  high = "#56B1F7",
  space = "Lab",
  na.value = "grey50",
  guide = "colourbar",
  aesthetics = "fill") +
  theme(legend.position="none")
